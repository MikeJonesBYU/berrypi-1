client2 is for client2test.py (a way to run a separate client on the same
laptop, for ease of development). 

The *_sample files need to be copied and renamed to not include "_sample".  
And the contents should be edited to define the new client.
