"""
Berry client package.
"""
from .client import BerryClient, send_message_to_server
from ._widget_config import get_widget
